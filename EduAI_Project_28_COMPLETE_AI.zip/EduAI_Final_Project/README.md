# EduAI — AI-Powered Personal Study Assistant

**CSE276: Artificial Intelligence Foundations — Project 28**

EduAI is a complete web-based AI learning platform designed around the official Project 28 requirement: an AI assistant that answers questions, generates quizzes, and provides study recommendations.

## Features
- AI question answering with OpenAI Responses API
- Demo fallback mode when no API key is configured
- Generative AI MCQ quiz creation
- Automatic quiz scoring
- Personalized recommendations based on performance
- Learning activity statistics
- Responsive modern dashboard
- Flask REST API
- Deployment-ready Procfile

## Run locally
1. Install Python 3.10+.
2. Open terminal in this folder.
3. `python -m venv .venv`
4. Windows: `.venv\\Scripts\\activate` | macOS/Linux: `source .venv/bin/activate`
5. `pip install -r requirements.txt`
6. Copy `.env.example` to `.env` and add `OPENAI_API_KEY` for live AI. If omitted, demo fallback mode works.
7. `python app.py`
8. Open `http://127.0.0.1:5000`

## Deployment
Deploy to any Flask-compatible host such as Render or Railway. Add `OPENAI_API_KEY` as a secret/environment variable and use the included `Procfile`.

## Academic mapping
Project 28: **AI-Powered Personal Study Assistant** — answers questions, generates quizzes, and provides study recommendations.

## Suggested viva points
- AI/NLP is used for question answering and quiz generation.
- Flask exposes REST endpoints between frontend and AI backend.
- The recommendation engine converts quiz performance into targeted advice.
- The fallback mode makes the demo usable without an external API.
